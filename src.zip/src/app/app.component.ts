import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent{
  title = 'angular-upload';
}

/*onFileSelect(event) {
  if (event.target.files.length > 0) {
    const file = event?.target.files[0];
    this.images = file;
  }
}

onsubmit(){
  const formData = new FormData();
  formData.append('file', this.images);
  this.http.post<any>('http://localhost:3000/file', formData).subscribe(
    (res) => console.log(res),
    (err) => console.log(err)
  );
}*/